# Habit Garden (Capacitor Android)

## Build the APK in the cloud (GitHub Actions)
1. Push this folder to a GitHub repository.
2. Open the Actions tab, run "Build Android APK" (it also runs on every push).
3. Download `habit-garden-apk` from the run, unzip it, install `app-debug.apk`.

## Build locally (Node 20+, JDK 17, Android SDK)
    npm install
    npm run setup:android     # runs "npx cap add android" once, adds permissions, then "npx cap sync android"
    npm run apk               # APK: android/app/build/outputs/apk/debug/app-debug.apk

After you edit `www/index.html`, run `npx cap sync android` and rebuild.

## Notifications
Reminders use native Capacitor Local Notifications (daily repeating alarms, exact timing,
restored after reboot). On first launch allow notifications. Test with the
"Send test notification (10 sec)" button on Home or in Settings, then close the app.
If a phone kills background apps aggressively, set Habit Garden's battery usage to "Unrestricted".
