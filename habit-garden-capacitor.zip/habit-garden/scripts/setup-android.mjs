// Creates the native android/ project (first run only), adds the permissions
// and notification icon needed for native reminders, then syncs the web app.
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execSync } from 'node:child_process';

const run = (c) => execSync(c, { stdio: 'inherit' });

if (!existsSync('android')) run('npx cap add android');

const manifest = 'android/app/src/main/AndroidManifest.xml';
let x = readFileSync(manifest, 'utf8');
const perms = [
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
  '<uses-permission android:name="android.permission.VIBRATE" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />',
  '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />',
];
const missing = perms.filter((p) => !x.includes(p.match(/android:name="([^"]+)"/)[1]));
if (missing.length) {
  x = x.replace('</manifest>', missing.map((p) => '    ' + p).join('\n') + '\n</manifest>');
  writeFileSync(manifest, x);
}

const dir = 'android/app/src/main/res/drawable';
mkdirSync(dir, { recursive: true });
writeFileSync(
  dir + '/ic_stat_icon.xml',
  `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
  <path android:fillColor="#FFFFFFFF" android:pathData="M6.05,8.05c-2.73,2.73 -2.73,7.15 -0.02,9.88 1.47,-3.4 4.09,-6.24 7.36,-7.93 -2.77,2.34 -4.71,5.61 -5.39,9.32 2.6,1.23 5.8,0.78 7.95,-1.37C19.43,14.47 20,4 20,4S9.53,4.57 6.05,8.05z"/>
</vector>
`
);

run('npx cap sync android');
console.log('Android project ready.');
